class AppConfig {
  static const String ipAddress = '192.168.158.112';
}
