import 'package:flutter/material.dart';
import 'src/my_app.dart';

void main() {
  runApp(MyApp());
}



